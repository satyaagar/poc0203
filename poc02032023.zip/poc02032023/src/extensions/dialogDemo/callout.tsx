import * as React from 'react';
import {
    mergeStyleSets,
    Callout,
    FocusZone,
    FocusZoneTabbableElements,
    FontWeights,
    Stack,
    Text,
} from '@fluentui/react';
import { useBoolean, useId } from '@uifabric/react-hooks';
import { DefaultButton, PrimaryButton } from '@fluentui/react/lib/Button';
import { RowAccessor } from '@microsoft/sp-listview-extensibility';
import { LinkPanel } from './LinkPanel';
export interface ICalloutFocusProps {
    rows: RowAccessor[];
    spcontext: any;
}
export const CalloutFocusTrapExample: React.FunctionComponent<ICalloutFocusProps> = (props) => {
    const [isCalloutVisible, { toggle: toggleIsCalloutVisible }] = useBoolean(true);
    const buttonId = useId('callout-button');
    const styles = mergeStyleSets({
        callout: {
            width: 220,
            padding: '20px 24px',
        },
        title: {
            marginBottom: 12,
            fontWeight: FontWeights.semilight,
        },
        buttons: {
            display: 'flex',
            justifyContent: 'flex-end',
            marginTop: 20,
        },
    });
    return (
        <>

            {isCalloutVisible ? (
                <Callout
                    role="alertdialog"
                    className={styles.callout}
                    gapSpace={0}
                    target={'button[name="Modal Popup"]'}
                    onDismiss={toggleIsCalloutVisible}
                    setInitialFocus
                >
                    <LinkPanel rows={props.rows} spcontext={props.spcontext} />
                </Callout>
            ) : null}
        </>
    );
};


