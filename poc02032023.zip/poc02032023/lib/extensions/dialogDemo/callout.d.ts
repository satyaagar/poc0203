import * as React from 'react';
import { RowAccessor } from '@microsoft/sp-listview-extensibility';
export interface ICalloutFocusProps {
    rows: RowAccessor[];
    spcontext: any;
}
export declare const CalloutFocusTrapExample: React.FunctionComponent<ICalloutFocusProps>;
//# sourceMappingURL=callout.d.ts.map