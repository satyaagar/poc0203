import * as React from "react";
import { RowAccessor } from "@microsoft/sp-listview-extensibility";
import "@pnp/sp/items";
import "@pnp/sp/attachments";
export interface IModalPopupProps {
    rows: RowAccessor[];
    spcontext: any;
}
export declare const ModalPopup: React.FunctionComponent<IModalPopupProps>;
//# sourceMappingURL=ModalPopup.d.ts.map